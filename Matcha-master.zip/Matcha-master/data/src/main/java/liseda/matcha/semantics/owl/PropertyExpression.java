/******************************************************************************
* A Property Expression encompasses Data and Object Property Expressions.     *
*                                                                             *
* @author Daniel Faria                                                        *
******************************************************************************/
package liseda.matcha.semantics.owl;

public interface PropertyExpression extends ValueExpression{}