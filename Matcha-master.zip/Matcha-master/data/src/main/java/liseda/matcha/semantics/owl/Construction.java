/******************************************************************************
* An expression based on the combination of expressions through intersection, *
* union, negation or compose operators.                                       *
*                                                                             *
* @author Daniel Faria                                                        *
******************************************************************************/
package liseda.matcha.semantics.owl;

import liseda.matcha.semantics.Expression;

public interface Construction extends Expression{}