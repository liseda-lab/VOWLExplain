/******************************************************************************
* Selector that uses (simulated) user interaction (through the Interaction    *
* Manager) to help perform alignment selection.                               *
*                                                                             *
* @author Daniel Faria, Amruta Nanavaty                                       *
******************************************************************************/

package liseda.matcha.match.lexical;

import java.util.ArrayList;

import liseda.matcha.alignment.Mapping;
import liseda.matcha.alignment.MappingRelation;
import liseda.matcha.match.AbstractParallelMatcher;
import liseda.matcha.semantics.EntityType;


public class AcronymMatcher extends AbstractParallelMatcher
{

//Attributes
	
	protected static final String DESCRIPTION = "Matches entities where the Lexicon entry of one\n" +
											  	"is an acronym of the Lexicon entry of the other\n";
	protected static final String NAME = "Acronym Matcher";
	protected static final EntityType[] SUPPORT = {EntityType.CLASS,EntityType.INDIVIDUAL,EntityType.DATA_PROP,EntityType.OBJECT_PROP};
			
//Constructors

	public AcronymMatcher()
	{
		super();
		description = DESCRIPTION;
		name = NAME;
		support = SUPPORT;
	}

	
//Protected Methods
	
	@Override
	protected Mapping mapTwoEntities(String s, String t)
	{
		double maxSim = 0.0;
		for(String sName : source.getLexicon(toMatch).getNames(s))
		{
			//Split the source name into words
			String[] srcWords = sName.split(" ");
			for(String tName : target.getLexicon(toMatch).getNames(t))
			{
				//Do the same for the target name
				String[] tgtWords = tName.split(" ");
				//Initialize the similarity
				double sim = 0.0;
				//Check whether source or target name is longer (has more words)
				//and put them both into ArrayLists
				ArrayList<String> longer = new ArrayList<String>();
				ArrayList<String> shorter = new ArrayList<String>();
				if(srcWords.length == tgtWords.length)
					continue;
				boolean sourceIsLonger = srcWords.length > tgtWords.length;
				if(sourceIsLonger)
				{
					for(String word : srcWords)
						longer.add(word);
					for(String word : tgtWords)
						shorter.add(word);
				}
				else
				{
					for(String word : srcWords)
						shorter.add(word);
					for(String word : tgtWords)
						longer.add(word);
				}
				int total = longer.size();
				//Check if they have shared words, and remove them
				for(int i = 0; i < shorter.size(); i++)
				{
					String word = shorter.get(i);
					if(longer.remove(word))
					{
						shorter.remove(i--);
						sim += 1.0;
					}
				}
				//We test for accronyms if the shorter name has exactly one word left after the removal step
				//AND that word has either 2 or 3 characters (longer potential acronyms will be ignored due
				//to the risk of being actual words) AND the length of the word corresponds to the number of
				//words left in the longer name
				if(shorter.size() != 1)
					continue;
				String acronym = shorter.get(0);
				if(acronym.length() < 2 || acronym.length() > 3 || acronym.length() != longer.size())
					continue;
				boolean match = true;
				for(int i = 0; i < longer.size(); i++)
				{
					String word = longer.get(i);
					match = word.startsWith(acronym.substring(i,i+1));
					if(match)
						sim += 0.5;
					else
						break;
				}
				if(!match)
					continue;
				sim /= total;
				if(maxSim > sim)
					maxSim = sim;
			}
		}
		return new Mapping(s, t, maxSim, MappingRelation.EQUIVALENCE, NAME);
	}
}